#define PCONP 	 (*(volatile int *)0x400FC0C4) // UART 3
#define PCLKSEL0 (*(volatile int *)0x400FC1A8) // 6,7
#define PINSEL0  (*(volatile int *)0x4002C004) // 2,3 AF 01

#define U0LCR	(*(volatile int *)0x4000800C) // UART Line Control Register 7번 bit 1설정
#define U0FCR	(*(volatile int *)0x4000C008) // UART FIFO Control Register 0번 bit 1로 설정 (FIFO enable)
#define U0LSR	(*(volatile int *)0x4000C014) // receive register 받은게 있으면 1
#define U0RBR	(*(volatile int *)0x4000C000) // receive register 0~7 bit안에 받은 데이터 저장
#define U0THR	(*(volatile int *)0x4000C000) 
#define U0TER	(*(volatile int *)0x4000C030) // 송신 하려면 1

#define FIO2PIN (*(volatile int *)0x2009C054) // 스위치

#include <string.h>
#include "led.h" // led 관련 헤더 함수 선언

// stop bit는 1로 설정, parity bit none => reset 0 따로 초기화 필요 없음
void UART0_Init()
{
	//PCONP |= (1<<3); // reset 값이 enable 되어있다.
	PCLKSEL0 |= (1<<6) + (1<<7);
	PINSEL0 |= (1<<4) + (1<<6); // tx bit + rx bit ,AF 01
	
	U0LCR |= (1<<1) + (1<<0); // Data 8 bit
	U0LCR |= (1<<7);
	U0FCR |= 1; // FIFO enable
	
	U0TER |= (1<<7);
}


int main()
{
	unsigned char ch;
	char c;
	unsigned char tx_buf[10]; // 받아온 문자열을 저장할 버퍼
	unsigned char cnt = 0; // 문자열의 위치
	
	led_Init(); // led 초기화
	UART0_Init(); // UART0 초기화
	
	while(1)
	{
		if(!(FIO2PIN & 0x00000400)) // 입력이 들어왔으면 저장
		{
			ch = 'A';
			
			while(!(U0LSR & 0x00000400));
			U0THR = ch;
			while(!(U0LSR & 0x00000800));
			c=U0RBR;
			
			
		}
	}
}














